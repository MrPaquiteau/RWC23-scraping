//
//  RWC23App.swift
//  Rugby-World-Cup-23
//
//  Created by Romain TROILLARD on 03/12/2023.
//

import SwiftUI

@main
struct RWC23App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
